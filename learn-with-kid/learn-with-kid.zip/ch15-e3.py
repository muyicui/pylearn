import random
list = []
for i in range(5):
    num = random.randint(0,20)
    list.append(num)
print(list)