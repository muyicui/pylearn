import random
import time
for i in range(11):
    print(random.random())
    time.sleep(3)