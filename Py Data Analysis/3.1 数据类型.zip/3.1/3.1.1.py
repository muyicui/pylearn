x = 1
y = 2

z = x > y

t = True
f = False

True & True
True & False
False & False

True | True
True | False
False | False

not True
not False
